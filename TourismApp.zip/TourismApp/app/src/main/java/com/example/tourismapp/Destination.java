package com.example.tourismapp;

public class Destination {
    private int id, image;
    public Destination(int id, int image)
    {
        this.id = id;
        this.image = image;
    }

    public int getId() { return id; }
    public int getImage() { return image; }

    public void setId(int Id) { this.id = Id; }
    public void setImage(int Image) { this.image = Image; }
}
