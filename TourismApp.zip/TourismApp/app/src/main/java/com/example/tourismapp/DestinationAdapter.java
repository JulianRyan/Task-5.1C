package com.example.tourismapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class DestinationAdapter extends RecyclerView.Adapter<DestinationAdapter.DestinationViewHolder> {
    private List<com.example.tourismapp.Destination> destinationList;
    private Context context;

    public DestinationAdapter(List<Destination> destinationList, Context context)
    {
        this.destinationList = destinationList;
        this.context = context;
    }

    @NonNull
    @Override
    public DestinationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.destinations_recycler_view, parent, false);
        return new DestinationViewHolder(itemView);
    }

    public class DestinationViewHolder extends RecyclerView.ViewHolder {
        public ImageView destinationImageView;
        public TextView nameTextView, addressTextView, priceTextView, ratingTextView, popularityTextView;

        public DestinationViewHolder (@NonNull View itemView) {
            super(itemView);
            destinationImageView = itemView.findViewById(R.id.destinationImageView);
        }
    }
    @Override
    public void onBindViewHolder(@NonNull DestinationAdapter.DestinationViewHolder holder, int position) {
        holder.destinationImageView.setImageResource(destinationList.get(position).getImage());
    }
    @Override
    public int getItemCount() { return destinationList.size(); }
}

