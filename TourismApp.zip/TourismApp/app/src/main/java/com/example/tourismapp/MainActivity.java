package com.example.tourismapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements PlaceAdapter.OnRowClickListener {
    RecyclerView destinationsRecyclerView;
    RecyclerView placesRecyclerView;
    DestinationAdapter destinationAdapter;
    PlaceAdapter placeAdapter;

    List<Destination> destinationList = new ArrayList<>();
    List<Place> placeList = new ArrayList<>();

    Integer[] placeImages = {R.drawable.goodhotel, R.drawable.badhotel, R.drawable.popularhotel, R.drawable.expensivehotel};
    Integer[] destinationImages = {R.drawable.newyork, R.drawable.bangkok, R.drawable.singapore};
    String[] Names = {"Ideal Hotel", "Bad Hotel", "Very Popular Hotel", "Expensive Hotel"};
    String[] Addresses = {"Generic Street", "Filthy Street", "Busy Street", "Golden Street"};
    Double[] Prices = {80.00, 10.00, 200.00, 3000.00};
    String[] Ratings = {"4/5", "1/5", "4/5", "5/5"};
    Integer[] Popularity = {600, 80, 5000, 20};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        destinationsRecyclerView = findViewById(R.id.destinationsRecyclerView);
        placesRecyclerView = findViewById(R.id.placesRecyclerView);
        destinationAdapter = new DestinationAdapter(destinationList, MainActivity.this);
        placeAdapter = new PlaceAdapter(placeList, MainActivity.this, this);
        destinationsRecyclerView.setAdapter(destinationAdapter);
        placesRecyclerView.setAdapter(placeAdapter);
        RecyclerView.LayoutManager horizontalLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        destinationsRecyclerView.setLayoutManager(horizontalLayoutManager);
        RecyclerView.LayoutManager verticalLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        placesRecyclerView.setLayoutManager(verticalLayoutManager);
        for (int i= 0 ; i< placeImages.length; i++)
        {
            com.example.tourismapp.Place place = new com.example.tourismapp.Place(i, placeImages[i], Names[i], Addresses[i], Prices[i], Ratings[i], Popularity[i]);
            placeList.add(place);
        }
        for (int i= 0 ; i< destinationImages.length; i++)
        {
            com.example.tourismapp.Destination destination = new com.example.tourismapp.Destination(i, destinationImages[i]);
            destinationList.add(destination);
        }
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, PlaceActivity.class);
        intent.putExtra("Image", placeImages[position]);
        intent.putExtra("Name", Names[position]);
        intent.putExtra("Address", Addresses[position]);
        intent.putExtra("Price", Prices[position]);
        intent.putExtra("Rating", Ratings[position]);
        intent.putExtra("Popularity", Popularity[position]);
        startActivityForResult(intent, RESULT_FIRST_USER);
    }
}