package com.example.tourismapp;

public class Place {
    private int id, image, popularity;
    private double price;
    private String name, address, rating;

    public Place(int Id, int Image, String Name, String Address, Double Price, String Rating, int Popularity)
    {
        this.id = Id;
        this.image = Image;
        this.name = Name;
        this.address = Address;
        this.rating = Rating;
        this.popularity = Popularity;
        this.price = Price;
    }

    public int getId() { return id; }
    public int getImage() { return image; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public Double getPrice() { return price; }
    public String  getRating() { return rating; }
    public int getPopularity() { return popularity; }

    public void setId(int Id) { this.id = Id; }
    public void setImage(int Image) { this.image = Image; }
    public void setName(String Name) { this.name = Name; }
    public void setAddress(String Address) { this.address = Address; }
    public void setPrice(double Price) { this.price = Price; }
    public void setRating(String Rating) { this.rating = Rating; }
    public void setPopularity(int Popularity) { this.popularity = Popularity; }
}
