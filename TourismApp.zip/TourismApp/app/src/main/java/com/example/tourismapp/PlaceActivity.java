package com.example.tourismapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class PlaceActivity extends AppCompatActivity {
    ImageView placeImageView2;
    TextView nameTextView2;
    TextView addressTextView2;
    TextView priceTextView2;
    TextView ratingTextView2;
    TextView popularityTextView2;
    Button backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place);

        backButton = findViewById(R.id.backButton);
        placeImageView2 = findViewById(R.id.placeImageView2);
        nameTextView2 = findViewById(R.id.nameTextView2);
        addressTextView2 = findViewById(R.id.addressTextView2);
        priceTextView2 = findViewById(R.id.priceTextView2);
        ratingTextView2 = findViewById(R.id.ratingTextView2);
        popularityTextView2 = findViewById(R.id.popularityTextView2);

        int image = getIntent().getIntExtra("Image", 0);
        String Name = getIntent().getStringExtra("Name");
        String Address = getIntent().getStringExtra("Address");
        Double Price = getIntent().getDoubleExtra("Price", 0);
        String Rating = getIntent().getStringExtra("Rating");
        int Popularity = getIntent().getIntExtra("Popularity", 0);

        placeImageView2.setImageResource(image);
        nameTextView2.setText("NAME: " + Name);
        addressTextView2.setText("ADDRESS: " + Address);
        priceTextView2.setText("PRICE: $" + Price.toString());
        ratingTextView2.setText("RATING: " + Rating + " STARS");
        popularityTextView2.setText("POPULARITY: " + String.valueOf(Popularity) + " PER DAY");

        backButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v){
                Intent intent = new Intent(PlaceActivity.this, MainActivity.class);
                startActivityForResult(intent, RESULT_FIRST_USER);;
            }
        });
    }


}