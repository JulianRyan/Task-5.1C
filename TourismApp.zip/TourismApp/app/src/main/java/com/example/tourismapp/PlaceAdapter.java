package com.example.tourismapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class PlaceAdapter extends RecyclerView.Adapter<PlaceAdapter.PlaceViewHolder> {
    private List<com.example.tourismapp.Place> placeList;
    private Context context;
    private OnRowClickListener listener;

    public PlaceAdapter(List<Place> placeList, Context context, OnRowClickListener clickListener)
    {
        this.placeList = placeList;
        this.context = context;
        this.listener = clickListener;
    }

    @NonNull
    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.places_recycler_view, parent, false);
        return new PlaceViewHolder(itemView, listener);
    }

    public interface OnRowClickListener {
        void onItemClick (int position);
    }

    public class PlaceViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView placeImageView;
        public TextView nameTextView, addressTextView, priceTextView, ratingTextView, popularityTextView;
        public OnRowClickListener onRowClickListener;

        public PlaceViewHolder (@NonNull View itemView, OnRowClickListener onRowClickListener) {
            super(itemView);
            placeImageView = itemView.findViewById(R.id.placeImageView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            addressTextView = itemView.findViewById(R.id.addressTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            ratingTextView = itemView.findViewById(R.id.ratingTextView);
            popularityTextView = itemView.findViewById(R.id.popularityTextView);
            this.onRowClickListener = onRowClickListener;
            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View view) {
            onRowClickListener.onItemClick(getAdapterPosition());
        }
    }
    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, int position) {
        holder.placeImageView.setImageResource(placeList.get(position).getImage());
        holder.addressTextView.setText("NAME: " + placeList.get(position).getAddress());
        holder.nameTextView.setText("ADDRESS: " + placeList.get(position).getName());
        holder.priceTextView.setText("PRICE: $" + placeList.get(position).getPrice().toString());
        holder.ratingTextView.setText("RATING: " + placeList.get(position).getRating() + " STARS");
        holder.popularityTextView.setText("POPULARITY: " + String.valueOf(placeList.get(position).getPopularity()) + " PER DAY");
    }
    @Override
    public int getItemCount() {
        return placeList.size();
    }



}
